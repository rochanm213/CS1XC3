/**
 * @mainpage Student & Course function demonstration
 * 
 * The student & course function demonstration shows how multiple functions in the student & course 
 * library work, including:
 * - enrolling students into a course
 * - printing course information
 * - finding the top student and printing their information
 * - finding all the passing students and printing their information
 * 
 * @file main.c
 * @author Rochan Muralitharan (muralr3@mcmaster.ca)
 * @date 12/04/2022
 * @version 0.1
 * @brief Runs demonstration for student and course library methods
 * 
 * @copyright Copyright (c) 2022
 */
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

int main()
{
  srand((unsigned) time(NULL));

  //create course
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  //randomly generage 20 students each with 8 grades
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  //find and print top student
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  //find and print all passing students
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}