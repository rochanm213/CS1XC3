/**
 * @file course.h 
 * @author Rochan Muralitharan (muralr3@mcmaster.ca)
 * @date 12/04/2022
 * @version 0.1
 * @brief Contains struct for course class and function declarations for all functions of the course class
 * 
 * @copyright Copyright (c) 2022
 */

#include "student.h"
#include <stdbool.h>

/**
 * Course type stores a course with fields name, code, students in the course and total number of students in the course
 * 
 */
typedef struct _course 
{
  char name[100]; /**< the course's name*/
  char code[10]; /**< the course's code*/
  Student *students; /**< students in the course*/
  int total_students; /**< the number of students in the course*/
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


