/**
 * @file course.c
 * @author Rochan Muralitharan (muralr3@mcmaster.ca)
 * @date 12/04/2022
 * @version 0.1
 * @brief Contains functions for course class
 * 
 * @copyright Copyright (c) 2022
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief Enrolls/adds a student to a course
 * 
 * @param course course to add student to
 * @param student student to be added to course
 * 
 * @return nothing
 */
void enroll_student(Course *course, Student *student)
{
  //if no students in course already, use calloc to create memory space and add student to course
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  //else, use realloc to create more memory space and add student to course
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief Prints course information
 * 
 * @param course course to print out information for
 * 
 * @return nothing
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief Finds and returns top student in the course
 * 
 * @param course course to find top student in
 * 
 * @return Top student in the course
 */
Student* top_student(Course* course)
{
  //if no students ,return NULL
  if (course->total_students == 0) return NULL;
 
 //cycle through all students, find and return student with highest average(use average function defined in course.c)
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief Finds and returns list of students who are passing the course(above 50% in course)
 * 
 * @param course course to find passing students in
 * @param total_passing number of students passing the course
 * 
 * @return List of students who are passing the course
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  //check each student to see if they are passing course, create memory space to hold info of all passing students
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  //check each student again to see if they are passing, if so, add student to the list, and return list
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}